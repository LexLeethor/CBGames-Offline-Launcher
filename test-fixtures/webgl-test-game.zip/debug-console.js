/// Processes all unity log messages and converts unity rich text to css styled console messages & adds a debug html debug console
/// from https://github.com/JohannesDeml/UnityWebGL-LoadingTest

let consoleDiv;
let debugToggle;
let logCounterDivs = {};
let logCounter = {
  "log": 0,
  "info": 0,
  "debug": 0,
  "warn": 0,
  "error": 0
};

let scrollToBottom = true;
if (getCookie("scrollToBottom") === "false") {
  scrollToBottom = false;
}
let addTimestamp = true;
if (getCookie("addTimestamp") === "false") {
  addTimestamp = false;
}

function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function initializeDebugConsole() {
  let debugConsole = document.createElement('div');
  debugConsole.id = 'debugConsole';
  document.body.appendChild(debugConsole);
  consoleDiv = document.createElement('div');
  consoleDiv.className = 'log-entries';

  addDebugConsoleTopBar(debugConsole);

  debugConsole.appendChild(consoleDiv);

  var consoleInput = document.createElement("input");
  consoleInput.className = 'console-input';
  consoleInput.type = "text";
  consoleInput.value = 'runUnityCommand("Help");';
  debugConsole.appendChild(consoleInput);

  consoleInput.onkeydown = function (e) {
    if (['Enter', 'NumpadEnter'].includes(e.key)) {
      console.log(`Evaluating ${consoleInput.value}`);
      eval(consoleInput.value);
    }
  };

  setupConsoleLogPipe();
}

function runUnityCommand(...command) {
  unityGame.SendMessage("WebBridge", ...command);
}

function addDebugConsoleTopBar(debugConsole) {
  var consoleTopBar = document.createElement('div');
  consoleTopBar.className = 'console-top-bar';
  debugConsole.appendChild(consoleTopBar);

  addTopBarLogCounter(consoleTopBar);

  var separator = document.createElement('div');
  separator.classList.add('separator', 'element');
  consoleTopBar.appendChild(separator);

  // Add timestamp toggle
  var timestampButton = document.createElement('button');
  timestampButton.classList.add('timestamp-button', 'bubble-click-indicator', 'element');
  timestampButton.title = 'Add timestamp to logs';
  consoleTopBar.appendChild(timestampButton);

  var timestampIcon = document.createElement('div');
  timestampIcon.classList.add('icon');
  timestampButton.appendChild(timestampIcon);
  applyTimestamp(timestampButton);

  timestampButton.addEventListener('click', function () {
    addTimestamp = !addTimestamp;
    setCookie("addTimestamp", addTimestamp, 365);
    applyTimestamp(timestampButton);
    // Show feedback to the user
    timestampButton.classList.add('active');
    setTimeout(function () {
      timestampButton.classList.remove('active');
    }, 1500);
  });

  // Lock scrolling to bottom button
  var toBottomButton = document.createElement('button');
  toBottomButton.classList.add('to-bottom-button', 'bubble-click-indicator', 'element');
  toBottomButton.title = 'lock scrolling to bottom';
  consoleTopBar.appendChild(toBottomButton);

  var arrowDownIcon = document.createElement('div');
  arrowDownIcon.classList.add('icon');
  toBottomButton.appendChild(arrowDownIcon);
  applyScrollToBottom(toBottomButton);

  toBottomButton.addEventListener('click', function () {
    scrollToBottom = !scrollToBottom;
    setCookie("scrollToBottom", scrollToBottom, 365);
    applyScrollToBottom(toBottomButton);
    // Show feedback to the user
    toBottomButton.classList.add('active');
    setTimeout(function () {
      toBottomButton.classList.remove('active');
    }, 1500);
  });

  // Clear logs button
  var clearButton = document.createElement('button');
  clearButton.classList.add('clear-button', 'bubble-click-indicator', 'element');
  clearButton.title = 'clear logs';
  consoleTopBar.appendChild(clearButton);

  var trashIcon = document.createElement('div');
  trashIcon.classList.add('icon');
  clearButton.appendChild(trashIcon);
  clearButton.addEventListener('click', function () {
    consoleDiv.innerHTML = '';
    clearButton.setAttribute('data-before', 'cleared');
    // Show feedback to the user
    clearButton.classList.add('active');
    setTimeout(function () {
      clearButton.classList.remove('active');
    }, 1500);
  });


  // Copy all logs button
  var copyButton = document.createElement('button');
  copyButton.classList.add('copy-button', 'bubble-click-indicator', 'element');
  copyButton.title = 'copy to clipboard';
  consoleTopBar.appendChild(copyButton);

  var copyIcon = document.createElement('div');
  copyIcon.classList.add('icon');
  copyButton.appendChild(copyIcon);

  copyButton.addEventListener('click', function () {
    if (navigator.clipboard) {
      var clipboardText = consoleDiv.innerText;
      navigator.clipboard.writeText(clipboardText).then(function () {
        copyButton.setAttribute('data-before', 'copied');
      }).catch(function () {
        copyButton.setAttribute('data-before', 'copy with navigator.clipboard failed');
      });
    } else {
      copyButton.setAttribute('data-before', 'copy failed - navigator.clipboard not supported');
    }

    // Show copy feedback to the user
    copyButton.classList.add('active');
    setTimeout(function () {
      copyButton.classList.remove('active');
    }, 1500);
  });
}

function addTopBarLogCounter(consoleTopBar) {

  addLogToggle = (logLevels) => {
    var counter = document.createElement('div');
    const logLevelsArray = logLevels.split(',');
    counter.classList.add('log-counter', 'bubble-click-indicator', 'element', ...logLevelsArray);
    counter.setAttribute('data-loglevels', logLevels);
    counter.title = logLevels;
    let count = 0;
    logLevelsArray.forEach(logLevel => {
      count += logCounter[logLevel];
      logCounterDivs[logLevel] = counter;
    });
    consoleTopBar.appendChild(counter);

    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `counter-${logLevels}`;
    checkbox.name = checkbox.id;
    checkbox.checked = true;
    checkbox.setAttribute('hidden', 'true');
    counter.appendChild(checkbox);

    var counterText = document.createElement('label');
    counterText.className = 'counter';
    counterText.htmlFor = checkbox.id;
    counterText.innerHTML = count;
    counter.appendChild(counterText);

    checkbox.addEventListener('change', (event) => {
      var logLevels = event.currentTarget.parentNode.getAttribute('data-loglevels');
      const logLevelsArray = logLevels.split(',');
      var debugConsole = document.getElementById('debugConsole');
      if (event.currentTarget.checked) {
        logLevelsArray.forEach(element => {
          debugConsole.classList.remove(`hidelogs-${element}`);
        });
      } else {
        logLevelsArray.forEach(element => {
          debugConsole.classList.add(`hidelogs-${element}`);
        });
      }
    })
  }

  addLogToggle('debug,log,info');
  addLogToggle('warn');
  addLogToggle('error');
}

function applyScrollToBottom(toBottomButton) {
  toBottomButton.setAttribute('data-before', scrollToBottom ? 'locked' : 'unlocked');
  if (scrollToBottom) {
    toBottomButton.classList.add("locked");
  } else {
    toBottomButton.classList.remove("locked");
  }
  applyScrollToBottomSetting();
}

function applyScrollToBottomSetting() {
  if (scrollToBottom) {
    consoleDiv.scrollTo(0, consoleDiv.scrollHeight);
  }
}

function applyTimestamp(timestampButton) {
  timestampButton.setAttribute('data-before', addTimestamp ? 'Show' : 'Hide');
  if (addTimestamp) {
    timestampButton.classList.add("show");
  } else {
    timestampButton.classList.remove("show");
  }
  applyTimestampSetting();
}

function applyTimestampSetting() {
  var debugConsole = document.getElementById('debugConsole');
  if (addTimestamp) {
    debugConsole.classList.remove("hidelogtimestamps");
  } else {
    debugConsole.classList.add("hidelogtimestamps");
  }
}

function setupConsoleLogPipe() {
  // Store actual console log functions
  let defaultConsoleLog = console.log;
  let defaultConsoleInfo = console.info;
  let defaultConsoleDebug = console.debug;
  let defaultConsoleWarn = console.warn;
  let defaultConsoleError = console.error;

  // Overwrite log functions to parse and pipe to debug html console
  console.log = (...args) => { handleLog(args, 'log', defaultConsoleLog); };
  console.info = (...args) => { handleLog(args, 'info', defaultConsoleInfo); };
  console.debug = (...args) => { handleLog(args, 'debug', defaultConsoleDebug); };
  console.warn = (...args) => { handleLog(args, 'warn', defaultConsoleWarn); };
  console.error = (...args) => { handleLog(args, 'error', defaultConsoleError); errorReceived(); };

  handleLog = (args, logLevel, consoleLogFunction) => {
    updateLogCounter(logLevel);
    const message = args.length ? args[0] : '';
    if (typeof message === 'string') {
      // Only parse messages that are actual strings
      parseMessageAndLog(args, logLevel, consoleLogFunction);
    } else {
      consoleLogFunction(...args);
      // Try to also log the object(s) to the html console (does not always work in a meaningful manner)
      var htmlMessage;
      try {
        htmlMessage = args.map(a => typeof a === 'string' ? a : JSON.stringify(a)).join(' ');
      } catch (error) {
        htmlMessage = `Can't convert message to JSON: ${error}`;
      }
      htmlLog(htmlMessage, logLevel);
    }
  };

  parseMessageAndLog = (args, logLevel, consoleLogFunction) => {
    const message = args.map(a => typeof a === 'string' ? a : JSON.stringify(a)).join(' ');
    let styledTextParts = parseUnityRichText(message);

    let consoleText = '';
    let consoleStyle = [];
    let htmlText = '';
    styledTextParts.forEach(textPart => {
      consoleText += textPart.toConsoleTextString();
      consoleStyle.push(textPart.toConsoleStyleString());
      htmlText += textPart.toHTML();
    });
    htmlLog(htmlText.trim(), logLevel);
    consoleLogFunction(...args);

    // Forward raw logs to auto-test, if active.
    if (window.__webglAutoTest && typeof window.__webglAutoTest.onLog === 'function') {
      window.__webglAutoTest.onLog(message, logLevel);
    }
  };
}

class StyledTextPart {
  constructor(text, styles) {
    this.text = text;
    this.styles = styles;
  }

  toHTML() {
    if (this.styles.length > 0) {
      return `<span style="${this.styles.join(';')}">${this.text}</span>`;
    }
    return this.text;
  }

  toConsoleStyleString() {
    if (this.styles.length > 0) {
      return this.styles.join(';');
    }
    // Return some styling that does not change anything to support unstyled text
    return 'color:inherit';
  }

  toConsoleTextString() {
    return `%c${this.text}`;
  }
}

function parseUnityRichText(message) {
  // Mapping for unity tags to css style tags
  // Unity rich text tags, see https://docs.unity3d.com/Packages/com.unity.ugui@1.0/manual/StyledText.html
  const tagMap = {
    'color': { startTag: '<color=', closeTag: '</color>', styleTag: 'color:', postfix: '', hasParameter: true },
    'size': { startTag: '<size=', closeTag: '</size>', styleTag: 'font-size:', postfix: 'px', hasParameter: true },
    'bold': { startTag: '<b', closeTag: '</b>', styleTag: 'font-weight:', styleValue: 'bold', hasParameter: false },
    'italic': { startTag: '<i', closeTag: '</i>', styleTag: 'font-style:', styleValue: 'italic', hasParameter: false }
  };

  let index = 0;
  const styledTextParts = [];

  // Stack of applied styles, so we can also nest styling
  let styleStack = [];
  // next start index for each tag
  let nextStartIndex = [];
  // next end index for each tag
  let nextEndIndex = [];
  Object.keys(tagMap).forEach(key => {
    nextStartIndex[key] = message.indexOf(tagMap[key].startTag, index);
    nextEndIndex[key] = message.indexOf(tagMap[key].closeTag, index);
  });

  while (index < message.length) {
    let nextTagFound = false;
    let nextKey;
    let fromArray = [];
    let nextIndex = message.length;

    // find the next tag start or end
    Object.keys(tagMap).forEach(key => {
      if (nextStartIndex[key] >= 0 && nextStartIndex[key] < nextIndex) {
        nextIndex = nextStartIndex[key];
        nextKey = key;
        fromArray = nextStartIndex;
        nextTagFound = true;
      }

      if (nextEndIndex[key] >= 0 && nextEndIndex[key] < nextIndex) {
        nextIndex = nextEndIndex[key];
        nextKey = key;
        fromArray = nextEndIndex;
        nextTagFound = true;
      }
    });

    // write the text in before the next tag to our style text part array
    if (nextIndex > index) {
      let messageToNextTag = message.substring(index, nextIndex);
      let styles = [...styleStack];
      styledTextParts.push(new StyledTextPart(messageToNextTag, styles));
    }

    // end if no more tags exist
    if (nextTagFound === false) {
      index = message.length;
      break;
    }

    let closeTagIndex = message.indexOf('>', nextIndex + 1);

    // Process start tag
    if (fromArray === nextStartIndex) {
      let styleValue;
      if (tagMap[nextKey].hasParameter) {
        styleValue = message.substring(nextIndex + tagMap[nextKey].startTag.length, closeTagIndex);
        styleValue += tagMap[nextKey].postfix;
      } else {
        styleValue = tagMap[nextKey].styleValue;
      }
      styleStack.push(`${tagMap[nextKey].styleTag}${styleValue}`);

      // Update list entry to next unprocessed start tag of type nextKey
      nextStartIndex[nextKey] = message.indexOf(tagMap[nextKey].startTag, nextIndex + 1);
    }
    // process end tag
    else if (fromArray === nextEndIndex) {
      styleStack.pop();

      // Update list entry to next unprocessed end tag of type nextKey
      nextEndIndex[nextKey] = message.indexOf(tagMap[nextKey].closeTag, nextIndex + 1);
    }

    // Update index to position after the tag closes
    index = closeTagIndex + 1;
  }
  return styledTextParts;
}

function updateLogCounter(logLevel) {
  logCounter[logLevel]++;

  counter = logCounterDivs[logLevel];
  const logLevels = counter.getAttribute('data-loglevels');
  const logLevelsArray = logLevels.split(',');
  let count = 0;
  logLevelsArray.forEach(logLevel => {
    count += logCounter[logLevel];
  });

  counter.querySelector(".counter").innerHTML = count;
}

function htmlLog(message, className) {
  var entry = document.createElement('div');
  entry.classList.add('entry', className);
  consoleDiv.appendChild(entry);

  var text = document.createElement('p');
  var time = new Date().toLocaleTimeString('en-US', {
    hour12: false,
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
  message = "<span class='timestamplog'>[" + time + "] </span>" + message;
  message = message.replaceAll("\n", "<br />");
  text.innerHTML = message;
  entry.appendChild(text);

  var copyButton = document.createElement('button');
  copyButton.classList.add('copy-button', 'bubble-click-indicator');
  copyButton.title = 'copy to clipboard';
  entry.appendChild(copyButton);

  var copyIcon = document.createElement('div');
  copyIcon.classList.add('icon');
  copyButton.appendChild(copyIcon);

  copyButton.addEventListener('click', function () {
    if (navigator.clipboard) {
      var clipboardText = text.innerText;
      navigator.clipboard.writeText(clipboardText).then(function () {
        copyButton.setAttribute('data-before', 'copied');
      }).catch(function () {
        copyButton.setAttribute('data-before', 'copy with navigator.clipboard failed');
      });
    } else {
      copyButton.setAttribute('data-before', 'copy failed - navigator.clipboard not supported');
    }

    // Show copy feedback to the user
    copyButton.classList.add('active');
    setTimeout(function () {
      copyButton.classList.remove('active');
    }, 1500);
  });


  if (scrollToBottom) {
    consoleDiv.scrollTo(0, consoleDiv.scrollHeight);
  }
}

function errorReceived() {
  if (debugToggle.checked === false) {
    let debugToggleMenu = document.getElementById('debugToggleMenu');
    debugToggleMenu.classList.remove('unseen-error');
    // trigger reflow
    debugToggleMenu.offsetWidth;
    debugToggleMenu.classList.add('unseen-error');
  }
}

function initializeToggleButton(startActive) {
  debugToggle = document.createElement('input');
  debugToggle.type = 'checkbox';
  debugToggle.id = 'debugToggle';
  debugToggle.name = 'debugToggle';
  debugToggle.checked = startActive;
  document.body.appendChild(debugToggle);

  var debugLabel = document.createElement('label');
  debugLabel.id = 'debugToggleMenu';
  debugLabel.htmlFor = 'debugToggle';
  document.body.appendChild(debugLabel);
  var iconDiv = document.createElement('div');
  iconDiv.classList = 'icon';
  debugLabel.appendChild(iconDiv);

  debugToggle.addEventListener('change', (event) => {
    if (event.currentTarget.checked) {
      applyScrollToBottomSetting();
      debugLabel.classList.remove('unseen-error');
    }

    if (typeof unityGame === 'undefined') {
      return;
    }
    if (event.currentTarget.checked) {
      runUnityCommand("DisableCaptureAllKeyboardInput");
      return;
    }

    if (typeof unityCaptureAllKeyboardInputDefault !== 'undefined' && unityCaptureAllKeyboardInputDefault === 'false') {
      runUnityCommand("DisableCaptureAllKeyboardInput");
    }
    else {
      runUnityCommand("EnableCaptureAllKeyboardInput");
    }
  })
}

function getInfoPanel() {
  let infoPanel = document.getElementById('infoPanel');

  if (infoPanel == null || infoPanel == 'undefined') {
    infoPanel = document.createElement('div');
    infoPanel.id = 'infoPanel';
    document.body.appendChild(infoPanel);
    var infoHeader = document.createElement('h3');
    if (typeof unityVersion != `undefined` && typeof applicationVersion != `undefined` && typeof webGlVersion != `undefined`) {
      // Set by WebGlBridge in Unity
      infoHeader.textContent = `Unity ${unityVersion}@${applicationVersion} (${webGlVersion})`;
    } else {
      infoHeader.textContent = `Unity InfoPanel`;
    }
    infoPanel.appendChild(infoHeader);
  }

  return infoPanel;
}

function setInfoPanelVisible(visible) {
  const infoPanel = getInfoPanel();
  if (visible) {
    infoPanel.style.visibility = 'visible';
  }
  else {
    infoPanel.style.visibility = 'hidden';
  }
}

function getOrCreateInfoEntry(id) {
  const infoPanel = getInfoPanel();
  var entry = infoPanel.querySelector(':scope > #' + id);

  if (entry == null || entry == 'undefined') {
    entry = document.createElement('div');
    entry.id = id;
    infoPanel.appendChild(entry);
  }

  return entry;
}

function onAddTimeTracker(eventName) {
  refreshTrackingDiv();
}

function onFpsTrackingEvent(fps) {
  const fpsDiv = getOrCreateInfoEntry('fps');
  fpsDiv.textContent = `FPS: ${fps.toFixed(1)}`;
}

function refreshTrackingDiv() {
  const trackingDiv = getOrCreateInfoEntry('tracking');
  let innerHtml = '<dl>';
  unityTimeTrackers.forEach((value, key, map) => {
    innerHtml += `<div id='tracking-${key}'>
                        <dt>${key}</dt>
                        <dd class='tracking-seconds'>${(value / 1000.0).toFixed(2)}</dd>
                        <dd class='tracking-milliseconds'>${value}</dd>
                      </div>`;
  });
  innerHtml += '</dl>';
  trackingDiv.innerHTML = innerHtml;
}

// Polyfill for older browsers
if (!String.prototype.replaceAll) {
  String.prototype.replaceAll = function(str, newStr) {
    if (str === '?')
      str = '\\\\?';
    return this.replace(str instanceof RegExp ? str : new RegExp(str, 'g'), newStr);
  }
}

const urlParams = new URLSearchParams(window.location.search);
const debugParam = urlParams.get('debug');
const debug = debugParam === 'true';

initializeToggleButton(debug);
initializeDebugConsole();

// ---------------------------------------------------------------------------
// Auto-test harness (trigger with ?autotest=1)
// ---------------------------------------------------------------------------

function createAutoTestState() {
  return {
    startedAt: Date.now(),
    logs: [],
    waiters: [],
    results: [],
    running: false,
    onLog(message) {
      this.logs.push(message);
      // Resolve any waiters whose pattern matches.
      this.waiters = this.waiters.filter(w => {
        if (w.pattern.test(message)) {
          w.resolve(message);
          return false;
        }
        return true;
      });
    }
  };
}

async function waitForUnity(timeoutMs) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (typeof unityGame !== 'undefined' && unityGame && typeof unityGame.SendMessage === 'function') {
      return;
    }
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error('Unity instance not ready');
}

function waitForLog(pattern, timeoutMs) {
  // Check historical logs first — synchronous Unity callbacks fire before the
  // waiter would be registered, so we must scan what already arrived.
  const hist = window.__webglAutoTest.logs.find(m => pattern.test(m));
  if (hist) return Promise.resolve(hist);

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error('Timeout waiting for log: ' + pattern));
    }, timeoutMs);
    window.__webglAutoTest.waiters.push({
      pattern,
      resolve: (msg) => {
        clearTimeout(timer);
        resolve(msg);
      }
    });
  });
}

function waitForAnyLog(patterns, timeoutMs) {
  // Check historical logs first (same race-condition fix as waitForLog).
  const hist = window.__webglAutoTest.logs.find(m => patterns.some(p => p.test(m)));
  if (hist) return Promise.resolve(hist);

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error('Timeout waiting for any log: ' + patterns.map(p => p.toString()).join(', ')));
    }, timeoutMs);
    window.__webglAutoTest.waiters.push({
      pattern: { test: (msg) => patterns.some(p => p.test(msg)) },
      resolve: (msg) => {
        clearTimeout(timer);
        resolve(msg);
      }
    });
  });
}

function deleteIndexedDb(name) {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.deleteDatabase(name);
      req.onsuccess = () => resolve(true);
      req.onerror = () => resolve(false);
      req.onblocked = () => resolve(false);
    } catch (_) {
      resolve(false);
    }
  });
}

async function clearIndexedDbAll() {
  if (typeof indexedDB === 'undefined' || indexedDB === null) return false;
  let deletedAny = false;
  if (indexedDB.databases) {
    try {
      const dbs = await indexedDB.databases();
      for (const db of dbs) {
        if (db && db.name) {
          const ok = await deleteIndexedDb(db.name);
          deletedAny = deletedAny || ok;
        }
      }
      return deletedAny;
    } catch (_) {
      // fall through to common names
    }
  }
  const commonNames = ['IDBFS', 'EM_FS', 'FILE_DATA', 'UnityCache', 'Unity Cache'];
  for (const name of commonNames) {
    const ok = await deleteIndexedDb(name);
    deletedAny = deletedAny || ok;
  }
  return deletedAny;
}

function updateAutoTestPanel(text) {
  const panel = getOrCreateInfoEntry('autotest');
  panel.textContent = text;
}

async function runAutoTestStep(name, fn) {
  try {
    console.log(`[AUTOTEST] START ${name}`);
    updateAutoTestPanel(`AutoTest: running ${name}`);
    await fn();
    console.log(`[AUTOTEST] PASS ${name}`);
    window.__webglAutoTest.results.push({ name, status: 'pass' });
  } catch (e) {
    console.error(`[AUTOTEST] FAIL ${name}: ${e.message || e}`);
    window.__webglAutoTest.results.push({ name, status: 'fail', error: e.message || String(e) });
  }
}

async function runWebglAutoTest() {
  if (window.__webglAutoTest && window.__webglAutoTest.running) return;
  window.__webglAutoTest = createAutoTestState();
  window.__webglAutoTest.running = true;

  const startTime = Date.now();
  const logTimeout = 10000;

  try {
    await waitForUnity(60000);
  } catch (e) {
    console.error('[AUTOTEST] Unity did not become ready in time.');
    updateAutoTestPanel('AutoTest: Unity not ready');
    return;
  }

  const safeCommands = [
    ['CheckOriginInfo'],
    ['CheckIdbAvailable'],
    ['CheckStorageQuota'],
    ['RegisterUnloadSync']
  ];

  for (const cmd of safeCommands) {
    await runAutoTestStep(cmd[0], async () => {
      runUnityCommand(...cmd);
      if (cmd[0] === 'CheckOriginInfo') {
        await waitForAnyLog([/Origin:/, /OriginInfo:/], logTimeout);
      }
      if (cmd[0] === 'CheckIdbAvailable') {
        await waitForAnyLog([/IdbAvailable/, /IdbUnavailable/], logTimeout);
      }
      if (cmd[0] === 'CheckStorageQuota') {
        await waitForAnyLog([/Storage:/, /StorageEstimate/], logTimeout);
      }
    });
  }

  await runAutoTestStep('MountIdbfs', async () => {
    runUnityCommand('MountIdbfs');
    const mountResult = await waitForAnyLog(
      [/Mount succeeded|MountSuccess|MountAlreadyMounted/, /Mount failed:|MountFailed:/],
      logTimeout
    );
    if (/Mount failed:|MountFailed:/.test(mountResult)) {
      console.warn('[AUTOTEST] Mount failed; attempting IndexedDB cleanup and retry...');
      await clearIndexedDbAll();
      runUnityCommand('MountIdbfs');
      await waitForLog(/Mount succeeded|MountSuccess|MountAlreadyMounted/, logTimeout);
    }
  });

  await runAutoTestStep('WriteIdbfsFile', async () => runUnityCommand('WriteIdbfsFile', 'autotest'));

  await runAutoTestStep('SyncIdbfs', async () => {
    runUnityCommand('SyncIdbfs');
    await waitForAnyLog([/Sync to IndexedDB succeeded|SyncSuccess/, /SyncSkipped/], logTimeout);
  });

  await runAutoTestStep('ReadIdbfsFile', async () => {
    runUnityCommand('ReadIdbfsFile');
    await waitForLog(/Read file:|Content:/, logTimeout);
  });

  await runAutoTestStep('LogIdbfsFiles', async () => runUnityCommand('LogIdbfsFiles'));
  await runAutoTestStep('TestDoubleMountGuard', async () => runUnityCommand('TestDoubleMountGuard'));
  await runAutoTestStep('TestConcurrentSync', async () => runUnityCommand('TestConcurrentSync'));
  await runAutoTestStep('TestLargeFileWrite', async () => runUnityCommand('TestLargeFileWrite', 1));
  await runAutoTestStep('TestUnicodeContent', async () => runUnityCommand('TestUnicodeContent'));
  await runAutoTestStep('TestWriteWithoutSync', async () => runUnityCommand('TestWriteWithoutSync'));
  await runAutoTestStep('TestReadBeforeMount', async () => runUnityCommand('TestReadBeforeMount'));

  // CommonCommands (best-effort; some require user gesture/permissions).
  const commonCommands = [
    ['AllocateByteArrayMemory', 4],
    ['CheckOnlineStatus'],
    ['CopyToClipboard', 'autotest'], // may be blocked
    ['DeleteAllPlayerPrefs'],
    ['DisableCaptureAllKeyboardInput'],
    ['EnableCaptureAllKeyboardInput'],
    ['FindGameObjectByName', 'WebBridge'],
    ['LogExampleMessages'],
    ['LogInitializationTime'],
    ['LogMemory'],
    ['LogMessage', 'autotest'],
    ['LogShaderCompilation', 0],
    ['LogTextureSupport'],
    ['LogUserAgent'],
    ['ReleaseByteArrayMemory'],
    ['SaveScreenshot'], // may be blocked
    ['SaveScreenshotSuperSize', 2], // may be blocked
    ['SetApplicationRunInBackground', 1],
    ['SetApplicationTargetFrameRate', 60],
    ['SetTimeFixedDeltaTime', 0.02],
    ['SetTimeTimeScale', 1.0],
    ['ToggleInfoPanel'],
    ['TriggerGarbageCollection'],
    ['UnloadUnusedAssets']
  ];

  for (const cmd of commonCommands) {
    await runAutoTestStep(cmd[0], async () => runUnityCommand(...cmd));
  }

  // -------------------------------------------------------------------------
  // Browser / WebGL feature probes (pure JS — no Unity command needed)
  // -------------------------------------------------------------------------

  await runAutoTestStep('BrowserWebGL2Caps', async () => {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) throw new Error('WebGL2 context unavailable');
    const maxTex     = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    const maxAttribs = gl.getParameter(gl.MAX_VERTEX_ATTRIBS);
    const maxUBOs    = gl.getParameter(gl.MAX_UNIFORM_BUFFER_BINDINGS);
    const renderer   = gl.getParameter(gl.RENDERER);
    const vendor     = gl.getParameter(gl.VENDOR);
    console.log(`[Browser] WebGL2: renderer="${renderer}" vendor="${vendor}" maxTexture=${maxTex} maxAttribs=${maxAttribs} maxUBOs=${maxUBOs}`);
    // Smoke-test: draw a red pixel and read it back
    gl.viewport(0, 0, 1, 1);
    gl.clearColor(1, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    const pixel = new Uint8Array(4);
    gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixel);
    if (pixel[0] !== 255 || pixel[1] !== 0 || pixel[2] !== 0)
      throw new Error(`WebGL2 clear+readPixels mismatch: [${pixel}]`);
    console.log('[Browser] WebGL2 clear+readPixels: PASSED');
    try { gl.getExtension('WEBGL_lose_context')?.loseContext(); } catch(_) {}
  });

  await runAutoTestStep('BrowserCanvas2D', async () => {
    const canvas = document.createElement('canvas');
    canvas.width = 64; canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context unavailable');
    ctx.fillStyle = '#00ff00';
    ctx.fillRect(0, 0, 64, 64);
    const d = ctx.getImageData(32, 32, 1, 1).data;
    if (d[0] !== 0 || d[1] !== 255 || d[2] !== 0)
      throw new Error(`Canvas 2D pixel mismatch: [${d[0]},${d[1]},${d[2]}]`);
    console.log('[Browser] Canvas 2D fillRect+getImageData: PASSED');
  });

  await runAutoTestStep('BrowserWebAssembly', async () => {
    if (typeof WebAssembly === 'undefined') throw new Error('WebAssembly not available');
    // Minimal valid wasm module (magic + version only)
    const minimalWasm = new Uint8Array([0,97,115,109,1,0,0,0]);
    const valid = WebAssembly.validate(minimalWasm);
    console.log(`[Browser] WebAssembly.validate(minimal): ${valid}`);
    if (!valid) throw new Error('WebAssembly.validate returned false for a valid module');
  });

  await runAutoTestStep('BrowserWebCrypto', async () => {
    if (!window.crypto || !crypto.getRandomValues)
      throw new Error('crypto.getRandomValues unavailable');
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    if (buf.every(b => b === 0)) throw new Error('getRandomValues returned all zeros');
    console.log(`[Browser] crypto.getRandomValues OK (sample bytes: ${buf[0]},${buf[1]},${buf[2]})`);
    console.log(`[Browser] crypto.subtle: ${'subtle' in crypto ? 'available' : 'unavailable'}`);
  });

  await runAutoTestStep('BrowserPerformanceAPI', async () => {
    if (!window.performance) throw new Error('performance API unavailable');
    const t0 = performance.now();
    await new Promise(r => setTimeout(r, 20));
    const elapsed20 = performance.now() - t0;
    console.log(`[Browser] performance.now() over 20ms setTimeout: ${elapsed20.toFixed(2)}ms`);
    if (performance.memory) {
      const m = performance.memory;
      console.log(`[Browser] performance.memory: used=${(m.usedJSHeapSize/1048576).toFixed(1)}MB ` +
                  `total=${(m.totalJSHeapSize/1048576).toFixed(1)}MB ` +
                  `limit=${(m.jsHeapSizeLimit/1048576).toFixed(0)}MB`);
    }
    const entries = performance.getEntriesByType('navigation');
    if (entries.length) {
      const nav = entries[0];
      console.log(`[Browser] navigation timing: domInteractive=${nav.domInteractive?.toFixed(0)}ms ` +
                  `loadEventEnd=${nav.loadEventEnd?.toFixed(0)}ms`);
    }
  });

  await runAutoTestStep('BrowserLocalStorage', async () => {
    const key = '__autotest_ls__', val = 'ok_' + Date.now();
    localStorage.setItem(key, val);
    const read = localStorage.getItem(key);
    localStorage.removeItem(key);
    if (read !== val) throw new Error(`localStorage round-trip failed: wrote "${val}", read "${read}"`);
    console.log('[Browser] localStorage read/write/delete: PASSED');
  });

  await runAutoTestStep('BrowserSessionStorage', async () => {
    const key = '__autotest_ss__', val = 'ss_' + Date.now();
    sessionStorage.setItem(key, val);
    const read = sessionStorage.getItem(key);
    sessionStorage.removeItem(key);
    if (read !== val) throw new Error(`sessionStorage round-trip failed: wrote "${val}", read "${read}"`);
    console.log('[Browser] sessionStorage read/write/delete: PASSED');
  });

  await runAutoTestStep('BrowserNavigatorInfo', async () => {
    const nav = navigator;
    console.log(`[Browser] Navigator: lang="${nav.language}" ` +
                `langs="${(nav.languages || []).slice(0,3).join(',')}" ` +
                `hardwareConcurrency=${nav.hardwareConcurrency} ` +
                `cookieEnabled=${nav.cookieEnabled} onLine=${nav.onLine}`);
    if (nav.deviceMemory !== undefined)
      console.log(`[Browser] deviceMemory: ~${nav.deviceMemory} GB`);
    if (nav.connection)
      console.log(`[Browser] Network: effectiveType=${nav.connection.effectiveType} ` +
                  `downlink=${nav.connection.downlink}Mbps rtt=${nav.connection.rtt}ms`);
  });

  await runAutoTestStep('BrowserScreenInfo', async () => {
    console.log(`[Browser] Screen: ${screen.width}x${screen.height} ` +
                `(avail ${screen.availWidth}x${screen.availHeight}) ` +
                `colorDepth=${screen.colorDepth}bit ` +
                `devicePixelRatio=${window.devicePixelRatio}`);
    if (screen.orientation)
      console.log(`[Browser] Screen.orientation: type="${screen.orientation.type}" angle=${screen.orientation.angle}`);
  });

  await runAutoTestStep('BrowserWorkerSupport', async () => {
    if (typeof Worker === 'undefined') throw new Error('Web Workers not supported');
    console.log(`[Browser] Worker: available`);
    console.log(`[Browser] SharedArrayBuffer: ${typeof SharedArrayBuffer !== 'undefined'}`);
    console.log(`[Browser] Atomics: ${typeof Atomics !== 'undefined'}`);
  });

  await runAutoTestStep('BrowserFetchAPI', async () => {
    if (typeof fetch === 'undefined') throw new Error('fetch API unavailable');
    // Fetch the page itself as a quick smoke-test (already cached)
    const res = await fetch(window.location.href, { method: 'HEAD' });
    console.log(`[Browser] fetch HEAD ${window.location.pathname}: status=${res.status}`);
  });

  await runAutoTestStep('BrowserWebRTC', async () => {
    const Ctor = window.RTCPeerConnection || window.webkitRTCPeerConnection;
    console.log(`[Browser] RTCPeerConnection: ${Ctor ? 'available' : 'unavailable'}`);
  });

  await runAutoTestStep('BrowserServiceWorker', async () => {
    console.log(`[Browser] ServiceWorker: ${'serviceWorker' in navigator ? 'available' : 'unavailable'}`);
  });

  await runAutoTestStep('BrowserFullscreenAPI', async () => {
    const enabled = document.fullscreenEnabled ?? document.webkitFullscreenEnabled;
    console.log(`[Browser] Fullscreen API: ${'fullscreenEnabled' in document || 'webkitFullscreenEnabled' in document ? 'available' : 'unavailable'} (enabled=${enabled})`);
  });

  await runAutoTestStep('BrowserPointerLockAPI', async () => {
    const ok = 'pointerLockElement' in document &&
               ('requestPointerLock' in document.documentElement ||
                'webkitRequestPointerLock' in document.documentElement);
    console.log(`[Browser] Pointer Lock API: ${ok ? 'available' : 'unavailable'}`);
  });

  await runAutoTestStep('BrowserPageVisibility', async () => {
    if (!('hidden' in document)) throw new Error('Page Visibility API unavailable');
    console.log(`[Browser] Page Visibility: hidden=${document.hidden} visibilityState="${document.visibilityState}"`);
  });

  await runAutoTestStep('BrowserGamepadAPI', async () => {
    if (!('getGamepads' in navigator)) {
      console.log('[Browser] Gamepad API: unavailable'); return;
    }
    const pads = Array.from(navigator.getGamepads()).filter(Boolean);
    console.log(`[Browser] Gamepad API: available, connected=${pads.length}`);
  });

  await runAutoTestStep('BrowserAudioContext', async () => {
    const Ctor = window.AudioContext || window.webkitAudioContext;
    if (!Ctor) { console.log('[Browser] AudioContext: unavailable'); return; }
    const ctx = new Ctor();
    console.log(`[Browser] AudioContext: state="${ctx.state}" sampleRate=${ctx.sampleRate}Hz`);
    await ctx.close();
  });

  await runAutoTestStep('BrowserObservers', async () => {
    const io = typeof IntersectionObserver !== 'undefined';
    const mo = typeof MutationObserver    !== 'undefined';
    const ro = typeof ResizeObserver      !== 'undefined';
    const po = typeof PerformanceObserver !== 'undefined';
    console.log(`[Browser] Observers: Intersection=${io} Mutation=${mo} Resize=${ro} Performance=${po}`);
    if (!mo) throw new Error('MutationObserver is required but unavailable');
  });

  await runAutoTestStep('BrowserHistoryAPI', async () => {
    if (!window.history?.pushState) throw new Error('History API (pushState) unavailable');
    console.log(`[Browser] History API: available, length=${history.length}`);
  });

  await runAutoTestStep('BrowserIndexedDB', async () => {
    if (typeof indexedDB === 'undefined') throw new Error('IndexedDB unavailable');
    // Quick open/close probe (already tested by IDBFS, but independently confirm)
    await new Promise((resolve, reject) => {
      const req = indexedDB.open('__autotest_probe__', 1);
      req.onsuccess = e => { e.target.result.close(); indexedDB.deleteDatabase('__autotest_probe__'); resolve(); };
      req.onerror   = e => reject(new Error('IndexedDB probe failed: ' + e.target.error));
      req.onblocked = () => reject(new Error('IndexedDB probe blocked'));
    });
    console.log('[Browser] IndexedDB open/close probe: PASSED');
  });

  // -------------------------------------------------------------------------
  // Launcher / file:// environment tests
  // Tests things that work normally over HTTP but may fail or behave differently
  // when run via the CBGames-Offline-Launcher (about:blank + blob: asset URLs).
  // -------------------------------------------------------------------------

  // Detect launcher context once, used by all tests below.
  // The reliable signals are: window.name set to the player target name, and
  // window.opener having the __loaderResolve function. We cannot rely on
  // window.location.href because Playwright (and some browsers) may report
  // a different URL for document.write()'d about:blank windows.
  const _inLauncher = (
    window.name === 'cbgamesOfflinePlayer' &&
    window.opener !== null &&
    !window.opener.closed &&
    typeof window.opener.__loaderResolve === 'function'
  );

  await runAutoTestStep('LauncherContextDetect', async () => {
    const href       = window.location.href;
    const proto      = window.location.protocol;
    const origin     = String(window.location.origin);
    const baseEl     = document.querySelector('base');
    const baseHref   = baseEl?.href || baseEl?.getAttribute('href') || '(none)';
    const baseURI    = document.baseURI;
    const winName    = window.name || '(empty)';
    const hasOpener  = window.opener !== null;
    const hasResolver = hasOpener && typeof window.opener.__loaderResolve === 'function';
    console.log(`[Launcher] href=${href} proto=${proto} origin=${origin}`);
    console.log(`[Launcher] baseHref=${baseHref} baseURI=${baseURI}`);
    console.log(`[Launcher] windowName=${winName} hasOpener=${hasOpener} hasResolver=${hasResolver}`);
    console.log(`[Launcher] inLauncher=${_inLauncher}`);
    // Informational — always passes
  });

  await runAutoTestStep('LauncherBaseHref', async () => {
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — base href check skipped');
      return;
    }
    const base = document.querySelector('base');
    if (!base) throw new Error('No <base> tag found — launcher did not inject a base element');
    const rawAttr = base.getAttribute('href') || '';
    const resolved = base.href || '';
    const baseURI  = document.baseURI;
    console.log(`[Launcher] <base> raw attr="${rawAttr}"`);
    console.log(`[Launcher] document.baseURI="${baseURI}"`);
    // The launcher rewrite pipeline sets the base href to https://loader.invalid/index.html,
    // but its own setAttribute patch then rewrites that virtual URL to the blob: URL of the
    // entry point (index.html). Both forms are valid — the resolver uses either.
    const isLoaderInvalid = rawAttr.startsWith('https://loader.invalid/') || resolved.startsWith('https://loader.invalid/');
    const isBlobEntry     = rawAttr.startsWith('blob:') || resolved.startsWith('blob:');
    if (!isLoaderInvalid && !isBlobEntry) {
      throw new Error(`Unexpected base href: raw="${rawAttr}" resolved="${resolved}" — expected loader.invalid or blob:`);
    }
    console.log(`[Launcher] Base href form: ${isLoaderInvalid ? 'loader.invalid virtual origin' : 'blob: entry-point URL'}`);
  });

  await runAutoTestStep('LauncherScriptBlobUrls', async () => {
    const scripts    = Array.from(document.scripts).filter(s => s.src);
    const blobScripts = scripts.filter(s => s.src.startsWith('blob:'));
    const otherSrcs  = scripts.filter(s => !s.src.startsWith('blob:')).map(s => s.src);
    console.log(`[Launcher] Script tags with src: ${scripts.length} total, ${blobScripts.length} blob:, ${otherSrcs.length} other`);
    if (otherSrcs.length) console.log(`[Launcher] Non-blob script srcs: ${otherSrcs.join(', ')}`);
    if (_inLauncher && scripts.length > 0 && blobScripts.length === 0) {
      throw new Error('In launcher but no scripts have blob: src — path rewrites may have failed');
    }
  });

  await runAutoTestStep('LauncherFetchRelativeAsset', async () => {
    // fetch('favicon.ico') — relative URL should be intercepted by the patched fetch
    // and served from IndexedDB via blob: URL.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — fetch intercept test skipped');
      return;
    }
    const res = await fetch('favicon.ico');
    if (!res.ok) throw new Error(`fetch('favicon.ico') failed: ${res.status} ${res.statusText}`);
    const buf = await res.arrayBuffer();
    console.log(`[Launcher] fetch('favicon.ico') intercepted OK — ${buf.byteLength} bytes, type=${res.headers.get('content-type') ?? 'unknown'}`);
  });

  await runAutoTestStep('LauncherFetchAbsoluteVirtual', async () => {
    // fetch('https://loader.invalid/favicon.ico') — absolute virtual-origin URL
    // should also resolve to the blob: asset via requestToObjectUrl.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — virtual-origin fetch test skipped');
      return;
    }
    // Use opener's resolver directly to get the canonical virtual URL for favicon.ico
    const blobUrl = window.opener.__loaderResolve('favicon.ico', document.baseURI);
    if (!blobUrl) throw new Error('__loaderResolve returned null for favicon.ico — asset not in ZIP?');
    const virtualUrl = 'https://loader.invalid/favicon.ico';
    const res = await fetch(virtualUrl);
    if (!res.ok) throw new Error(`fetch('${virtualUrl}') failed: ${res.status}`);
    const buf = await res.arrayBuffer();
    console.log(`[Launcher] fetch(virtual-origin 'https://loader.invalid/favicon.ico') intercepted OK — ${buf.byteLength} bytes`);
  });

  await runAutoTestStep('LauncherXHRRelativeAsset', async () => {
    // XMLHttpRequest to a relative path — should be intercepted like fetch.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — XHR intercept test skipped');
      return;
    }
    await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', 'favicon.ico');
      xhr.responseType = 'arraybuffer';
      xhr.onload = () => {
        if (xhr.status === 200) {
          console.log(`[Launcher] XHR('favicon.ico') intercepted OK — ${xhr.response.byteLength} bytes`);
          resolve();
        } else {
          reject(new Error(`XHR status ${xhr.status}`));
        }
      };
      xhr.onerror = () => reject(new Error('XHR network error'));
      xhr.send();
    });
  });

  await runAutoTestStep('LauncherDynamicImgSrcPatch', async () => {
    // Dynamically setting img.src should be intercepted by the patchProperty setter.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — img.src patch test skipped');
      return;
    }
    const img = document.createElement('img');
    img.src = 'favicon.ico';
    const assignedSrc = img.src; // read back — if patched, should be blob:
    console.log(`[Launcher] img.src after set: ${assignedSrc.substring(0, 60)}`);
    if (!assignedSrc.startsWith('blob:')) {
      throw new Error(`img.src was not rewritten to blob: — got: ${assignedSrc}`);
    }
    // Actually load it and confirm it delivers bytes
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = () => reject(new Error('img failed to load from blob: src'));
      document.body.appendChild(img);
      setTimeout(() => reject(new Error('img load timeout')), 5000);
    });
    img.remove();
    console.log('[Launcher] img.src setter intercepted and asset loaded OK');
  });

  await runAutoTestStep('LauncherDynamicScriptSrcPatch', async () => {
    // Dynamically setting script.src should be intercepted to blob:
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — script.src patch test skipped');
      return;
    }
    const script = document.createElement('script');
    script.src = 'debug-console.js';
    const assignedSrc = script.src;
    console.log(`[Launcher] script.src after set: ${assignedSrc.substring(0, 60)}`);
    if (!assignedSrc.startsWith('blob:')) {
      throw new Error(`script.src was not rewritten to blob: — got: ${assignedSrc}`);
    }
    console.log('[Launcher] script.src setter intercepted OK (not appending — would re-run globals)');
  });

  await runAutoTestStep('LauncherWorkerUrlPatch', async () => {
    // new Worker('relative.js') should be intercepted — Worker constructor is patched.
    // We test by checking if a simple inline worker blob: URL resolves correctly.
    // Creating a worker from the mapped path of a known asset confirms interception.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — Worker URL patch test skipped');
      return;
    }
    // Resolve a known asset path to blob: via opener
    const blobUrl = window.opener.__loaderResolve('debug-console.js', document.querySelector('base')?.href || document.baseURI);
    if (!blobUrl) throw new Error('__loaderResolve returned null for debug-console.js');
    console.log(`[Launcher] __loaderResolve('debug-console.js') → ${blobUrl.substring(0, 50)}...`);
    // Verify the Worker constructor is patched
    const workerCode = `self.onmessage = e => self.postMessage('pong');`;
    const workerBlob = new Blob([workerCode], { type: 'application/javascript' });
    const workerUrl  = URL.createObjectURL(workerBlob);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { worker.terminate(); reject(new Error('Worker timeout')); }, 5000);
      const worker = new Worker(workerUrl);
      worker.onmessage = e => {
        clearTimeout(timer);
        worker.terminate();
        URL.revokeObjectURL(workerUrl);
        console.log(`[Launcher] Worker from blob: responded: ${e.data}`);
        resolve();
      };
      worker.onerror = e => { clearTimeout(timer); reject(new Error('Worker error: ' + e.message)); };
      worker.postMessage('ping');
    });
  });

  await runAutoTestStep('LauncherRelativeDynamicImport', async () => {
    // import('./relative.js') resolves against document.baseURI = https://loader.invalid/
    // This will fail with a network error — import() is NOT intercepted by the launcher.
    // This is expected FATAL behavior for ES-module games.
    let gotNetworkError = false;
    try {
      await import('./___nonexistent_module_autotest___.mjs');
    } catch (e) {
      gotNetworkError = true;
      const msg = e.message || String(e);
      console.log(`[Launcher] import('./relative') error (expected): ${msg.substring(0, 120)}`);
    }
    if (!gotNetworkError) throw new Error('Expected import() to fail — ES module interception appears to work (unexpected)');
    console.log('[Launcher] Confirmed: relative dynamic import() fails — ES module games would need static rewriting');
  });

  await runAutoTestStep('LauncherAbsoluteBlobImport', async () => {
    // import() with an absolute blob: URL should work — the browser can always fetch blob: URLs.
    const moduleCode = `export const value = 'launcher-module-ok';`;
    const moduleBlob = new Blob([moduleCode], { type: 'application/javascript' });
    const moduleUrl  = URL.createObjectURL(moduleBlob);
    try {
      const mod = await import(moduleUrl);
      if (mod.value !== 'launcher-module-ok') throw new Error('Module exported wrong value: ' + mod.value);
      console.log('[Launcher] import(blob:url) works — absolute blob: imports are fine');
    } finally {
      URL.revokeObjectURL(moduleUrl);
    }
  });

  await runAutoTestStep('LauncherSendBeacon', async () => {
    // navigator.sendBeacon is NOT intercepted by the launcher.
    // Sending to a real URL from about:blank context — informational.
    if (typeof navigator.sendBeacon !== 'function') {
      console.log('[Launcher] sendBeacon: not available');
      return;
    }
    // Test with a blob: URL (safe — no real network)
    const blob = new Blob(['beacon-payload'], { type: 'text/plain' });
    const url  = URL.createObjectURL(blob);
    let result;
    try {
      result = navigator.sendBeacon(url, 'test');
    } catch (e) {
      console.log(`[Launcher] sendBeacon(blob:) threw: ${e.message}`);
      result = false;
    } finally {
      URL.revokeObjectURL(url);
    }
    console.log(`[Launcher] sendBeacon(blob:) returned: ${result} (true=queued, false=rejected)`);
    // Informational — not a failure
  });

  await runAutoTestStep('LauncherCookiesAboutBlank', async () => {
    const before = document.cookie;
    document.cookie = '__launcher_test__=1; SameSite=Strict';
    const after = document.cookie;
    const wasSet = after.includes('__launcher_test__');
    if (wasSet) {
      document.cookie = '__launcher_test__=; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Strict';
    }
    console.log(`[Launcher] document.cookie writable from ${window.location.protocol}: ${wasSet}`);
    console.log(`[Launcher] Cookies ${wasSet ? 'work' : 'are blocked'} — ${wasSet ? 'unexpected for about:blank/file://' : 'expected, games using cookies will fail'}`);
    // Informational — not a failure either way
  });

  await runAutoTestStep('LauncherCrossOriginStatus', async () => {
    const coi = window.crossOriginIsolated === true;
    const sab = typeof SharedArrayBuffer !== 'undefined';
    const atomics = typeof Atomics !== 'undefined';
    console.log(`[Launcher] crossOriginIsolated: ${coi}`);
    console.log(`[Launcher] SharedArrayBuffer: ${sab}`);
    console.log(`[Launcher] Atomics: ${atomics}`);
    if (!coi) {
      console.log('[Launcher] No cross-origin isolation — Unity multithreading disabled, SAB unavailable');
    }
    // Informational — both coi=true and coi=false are valid outcomes
  });

  await runAutoTestStep('LauncherOpenerAccess', async () => {
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — opener access test skipped');
      return;
    }
    if (window.opener === null || window.opener === undefined) {
      throw new Error('window.opener is null — launcher communication is broken');
    }
    if (window.opener.closed) {
      throw new Error('window.opener is closed — launcher window was shut');
    }
    // Try accessing a property to verify same-origin access
    const hasResolver = typeof window.opener.__loaderResolve === 'function';
    if (!hasResolver) throw new Error('window.opener.__loaderResolve missing — launcher bridge incomplete');
    console.log('[Launcher] window.opener accessible and has resolver — launcher bridge OK');
    // Test postMessage to opener (fire-and-forget, no reply expected)
    window.opener.postMessage({ type: '__autotest_ping__', from: 'popup' }, '*');
    console.log('[Launcher] postMessage to opener: sent (no reply handler in launcher)');
  });

  await runAutoTestStep('LauncherPatchedDynamicImport', async () => {
    // Verifies that patchDynamicImports() rewrote the import() call below to
    // use an absolute blob: URL BEFORE this script ran.  The launcher scans all
    // game JS files at launch time and replaces import('string-literal') with
    // import('blob:null/{uuid}') so that relative dynamic imports work inside
    // the about:blank popup where relative URL resolution is broken.
    //
    // When NOT in the launcher the import resolves against the real dev-server
    // URL (http://localhost:…/test-module.js) which also works — so the test
    // passes in both environments.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — using real URL resolution for import()');
    }
    // This exact string is what patchDynamicImports() scans for:
    const mod = await import('./test-module.js');
    if (!mod || mod.launcherImportTest !== 'patch-worked') {
      throw new Error('Module import returned wrong value: ' + JSON.stringify(mod?.launcherImportTest));
    }
    console.log('[Launcher] test-module.js resolved OK — patchDynamicImports() is working');
  });

  await runAutoTestStep('LauncherFetchUnknownAssetFallback', async () => {
    // fetch() for an asset not in the game ZIP — launcher returns null from requestToObjectUrl,
    // so it falls back to the real network (https://loader.invalid/missing.xyz → DNS error).
    // This is the "missing asset" fatal path.
    if (!_inLauncher) {
      console.log('[Launcher] Not in launcher — missing-asset fallback test skipped');
      return;
    }
    let failedAsExpected = false;
    try {
      await fetch('___does_not_exist_autotest___.bin');
    } catch (e) {
      failedAsExpected = true;
      console.log(`[Launcher] fetch(unknown asset) failed as expected: ${String(e.message).substring(0, 100)}`);
    }
    if (!failedAsExpected) {
      throw new Error('Expected fetch for unknown asset to fail — it should not silently succeed');
    }
    console.log('[Launcher] Missing asset correctly fails (no silent fallback to bad data)');
  });

  await runAutoTestStep('LauncherWasmFetchDirect', async () => {
    // Main-page fetch of test.wasm — served via fetch interceptor in the launcher,
    // or via the dev-server when running standalone.  Either way it must succeed
    // and deliver a valid WebAssembly module.
    const resp = await fetch('test.wasm');
    if (!resp.ok) throw new Error(`fetch('test.wasm') HTTP ${resp.status}`);
    const buf = await resp.arrayBuffer();
    if (!WebAssembly.validate(new Uint8Array(buf)))
      throw new Error('test.wasm bytes failed WebAssembly.validate');
    console.log(`[Launcher] fetch(test.wasm) OK — ${buf.byteLength} bytes, valid wasm`);
  });

  await runAutoTestStep('LauncherWorkerWasmInline', async () => {
    // Worker-side WASM inlining: the launcher pre-processes test-worker-wasm.js
    // and replaces the literal "test.wasm" with a data: URL before the worker
    // runs, because workers can't use the fetch interceptor.
    // In the dev-server (no launcher) the worker fetches test.wasm from the
    // server instead — both paths must result in a valid wasm instantiation.
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => { w.terminate(); reject(new Error('Worker wasm timeout')); }, 8000);
      const w = new Worker('./test-worker-wasm.js');
      w.onmessage = e => {
        clearTimeout(timer);
        w.terminate();
        const { ok, inlined, error } = e.data;
        if (!ok) return reject(new Error('Worker wasm failed: ' + error));
        if (_inLauncher && !inlined)
          return reject(new Error('Running in launcher but "test.wasm" was NOT inlined as data: URL'));
        console.log(`[Launcher] Worker wasm instantiation OK — inlined=${inlined} (_inLauncher=${_inLauncher})`);
        resolve();
      };
      w.onerror = e => { clearTimeout(timer); reject(new Error('Worker error: ' + e.message)); };
      w.postMessage('go');
    });
  });

  // -------------------------------------------------------------------------
  // New Unity WebGL info commands (added in WebGLTestCommands.cs)
  // Fire-and-forget — they log info but we don't block the test on a pattern.
  // -------------------------------------------------------------------------
  const unityInfoCommands = [
    ['LogScreenInfo'],
    ['LogSystemInfo'],
    ['LogApplicationInfo'],
    ['LogQualitySettings'],
    ['LogGraphicsCapabilities'],
    ['LogRenderTextureSupport'],
    ['LogInputCapabilities'],
    ['LogTimeInfo'],
    ['TestPlayerPrefsRoundTrip'],
  ];

  for (const cmd of unityInfoCommands) {
    await runAutoTestStep(cmd[0], async () => runUnityCommand(...cmd));
  }

  // Report summary
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  const failed = window.__webglAutoTest.results.filter(r => r.status === 'fail');
  const passed = window.__webglAutoTest.results.filter(r => r.status === 'pass');
  console.log(`[AUTOTEST] DONE in ${elapsed}s — ${passed.length} passed, ${failed.length} failed`);
  updateAutoTestPanel(`AutoTest: ${passed.length} passed, ${failed.length} failed in ${elapsed}s`);
  if (failed.length) {
    console.warn('[AUTOTEST] Failed steps:', failed);
  }
  window.__webglAutoTest.running = false;
}

const autoTestParam = urlParams.get('autotest');
if (autoTestParam === '1' || autoTestParam === 'true') {
  runWebglAutoTest();
}
