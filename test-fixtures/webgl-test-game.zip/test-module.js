// Minimal ES module used by LauncherPatchedDynamicImport autotest.
// The launcher's patchDynamicImports() rewrites any import('./test-module.js')
// in game source files to the absolute blob: URL for this file before launch.
export const launcherImportTest = 'patch-worked';
