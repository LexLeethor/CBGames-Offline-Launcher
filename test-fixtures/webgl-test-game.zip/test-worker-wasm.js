// test-worker-wasm.js
// Used by the LauncherWorkerWasmInline autotest step.
//
// When loaded via the launcher, the wasm path constant below is replaced
// with a data:application/wasm;base64,… URL at load time by
// patchEmscriptenWasmScriptText — proving WASM inlining ran on this worker.
// When loaded from the dev-server the string stays as-is and fetch resolves
// it relative to the worker's own URL (http://localhost/test.wasm).
self.onmessage = async function () {
  try {
    const wasmRef = "test.wasm";
    const resp = await fetch(wasmRef);
    const buf = await resp.arrayBuffer();
    await WebAssembly.instantiate(buf);
    self.postMessage({ ok: true, inlined: wasmRef.startsWith('data:') });
  } catch (err) {
    self.postMessage({ ok: false, error: String(err) });
  }
};
